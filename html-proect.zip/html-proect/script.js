      function mesaj(){
        console.log('SITE_OPEN');
            alert("Нажмите кнопку 'ок' чтоб принять политику конфиденциальности сайта");
        }